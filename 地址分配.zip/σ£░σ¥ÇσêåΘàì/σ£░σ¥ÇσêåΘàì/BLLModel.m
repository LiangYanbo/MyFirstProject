//
//  BLLModel.m
//  地址分配
//
//  Created by LiteTrace on 2017/8/7.
//  Copyright © 2017年 LiteTrace. All rights reserved.
//

#import "BLLModel.h"

@implementation BLLModel

@end
